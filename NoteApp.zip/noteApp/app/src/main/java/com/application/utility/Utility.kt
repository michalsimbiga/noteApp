package com.application.utility

import timber.log.Timber

class Utility {

    init {
        Timber.d("Utility class created")
    }
}