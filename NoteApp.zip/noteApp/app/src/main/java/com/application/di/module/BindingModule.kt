package com.application.di.module

import dagger.Module

@Module
class BindingModule